# Auto-Loop

An Idea-driven template for multi-agent research exploration. A coordinator manages the workflow; different agents provide research guidance and exploration execution. Reviewers uninvolved in the reviewed version independently verify computation and scientific interpretation.

The only formal rules are in [AGENTS.md](AGENTS.md), currently v1.9 (cross-platform open-source edition). This README explains usage. The skill and role configurations implement the workflow without adding or replacing rules. [Idea.md](Idea.md) is an unstarted example; there are no real project data, experiments, or scientific conclusions.

## Files

```text
Auto-Loop/
|-- AGENTS.md                         # Human-maintained formal rules; read-only
|-- Idea.md                           # Research input with a detailed example
|-- README.md                         # Usage and project description entry point
|-- LOOP.md                           # The single exploration record
|-- .agents/skills/auto-loop/
|   |-- SKILL.md                      # Coordinator workflow
|   `-- agents/openai.yaml            # Skill interface metadata
`-- .codex/agents/
    |-- Guide.toml                    # research_guide
    |-- Executor.toml                 # research_executor
    `-- Reviewer.toml                 # research_reviewer
```

Keep the hidden `.agents` and `.codex` directories and root files when moving the workflow. Create material, data, method, experiment, and figure directories only as needed; the template does not pre-create empty directories. The open-source package contains no real research data, results, or template maintenance history. [LOOP.md](LOOP.md) begins with the actual state of a new project.

## Prepare and Start

1. Open the actual project root in a local Codex environment and start the coordinating chat there.
2. The human checks the formal rules and suitable protection for the actual system, including after copying or cloning. On Windows, inspect the read-only attribute and actual ACL information. On macOS, check write permissions and any human-set `uchg` flag. On Linux/WSL, inspect permissions on the actual filesystem. Basic read-only settings do not establish a boundary agents cannot change. Agents do not modify rules or protection. See the platform preparation commands below.
3. Replace the whole `Idea.md` example with the real question, material acquisition and access conditions, stage goal, and task budget. Set its status to "ready for exploration." Methods, specific baselines, and exploration routes may remain for agents to determine.
4. Send this prompt in the coordinating chat:

```text
Use the auto-loop skill and read the current project's Idea.md.
I authorize native Codex multi-agent collaboration for this task under root AGENTS.md.
Coordinate the work and actually delegate guidance, execution, and independent review.
Choose role counts according to the research questions; keep guidance and execution separate.
Write and actually execute data processing, training, evaluation, recomputation, and plotting
directly in .ipynb files. Do not create or invoke custom .py files or wrap scripts in notebooks.
Continue within the scope and budget in Idea. Handle ordinary debugging and exploration
within the authorized approach autonomously. Guidance checks evidence for important route changes;
stage conclusions undergo independent verification and scientific review.
Keep progress, evidence versions, agent identities, review statuses, and disagreements in LOOP.md.
If Idea is still an example, check input and report missing information without starting research.
```

Preserve the original human Idea; record checks, plans, and subsequent changes in `LOOP.md`. Reuse existing explicit authorization without reconfirming each normal iteration. When creating a new project, initialize `LOOP.md` to its actual state rather than treating template maintenance history as research evidence.

## Platform Preparation

The human runs the applicable commands from the project root:

- Windows (PowerShell): run `attrib +R ".\AGENTS.md"`, then inspect the read-only attribute and ACL with `Get-Item -LiteralPath ".\AGENTS.md" | Select-Object Name, IsReadOnly` and `icacls ".\AGENTS.md"`.
- macOS: run `chmod a-w AGENTS.md` and `chflags uchg AGENTS.md`, then inspect with `ls -lO AGENTS.md`.
- Linux/WSL: run `chmod a-w AGENTS.md`, then inspect with `ls -l AGENTS.md`. For Windows-mounted WSL paths, inspect Windows permissions too.

Ordinary read-only attributes or permissions may be removable by the same account. Stronger boundaries require a human-configured execution environment agents cannot change. ZIP archives and Git do not guarantee protection survives. See Microsoft's [attrib](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/attrib), [icacls](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls), and [WSL permissions](https://learn.microsoft.com/en-us/windows/wsl/file-permissions) documentation.

Prepare a notebook kernel and execution tool, such as `ipykernel` and `nbclient`, in the chosen Python environment. Scientific dependencies depend on the actual project. Before startup, identify the shell, Python/notebook kernel, dependencies, paths, and devices. Do not mix native Windows and WSL environments. Windows can use PowerShell; see the [Codex Windows documentation](https://learn.chatgpt.com/docs/windows/windows-sandbox).

Computation follows R-003. Select MPS on macOS, a backend such as CUDA on Windows/Linux/WSL, or CPU according to actual support rather than assuming a GPU model. In Windows notebooks using PyTorch DataLoader, first verify with `num_workers=0` before increasing workers. See the [PyTorch Windows FAQ](https://docs.pytorch.org/docs/stable/notes/windows.html). Research logic still lives directly in `.ipynb` files.

## Run and Hand Off

The workflow entry point is the [auto-loop skill](.agents/skills/auto-loop/SKILL.md):

```text
Read progress -> guidance selects the question and evidence requirements -> record question and method
-> execution implements, checks a small case, and runs experiments -> inspect actual runs and freeze evidence
-> independently verify computation and scientific interpretation -> repair, add evidence, revise, or accept a bounded conclusion
-> update progress and continue
```

![Auto-Loop research cycle](Workflow.jpg)

Research code follows R-004: the actual entry points are `.ipynb` files, models and functions are defined directly in cells, and results come from actual notebook execution. Headless execution still runs notebooks without exporting or invoking custom `.py` files. Generate figures by reloading existing models for recomputation, retaining necessary execution information and key results.

Each of the three roles may have multiple instances within actual slot, resource, and write-path constraints. Guidance and execution read current progress and relevant history. Reviewers inspect frozen original evidence before author interpretation, using fresh contexts when available. Record experiment completion and review acceptance separately. Retain computationally correct negative findings; guidance checks evidence and selects the next justified exploration.

Each agent reads the relevant shared project files directly. A concise handoff gives the exploration identifier, question, scope, evidence version and location, writable paths, budget, and unverified items. Messages do not replace evidence or human authorization. The coordinator maintains `LOOP.md` and the main README centrally; do not add JSON state or per-agent logs.

If the client does not discover role names but native subagents exist, ask ordinary subagents to read the corresponding TOML and record them as file-bound roles. If the skill is missing from the selector, ask Codex to read `.agents/skills/auto-loop/SKILL.md` directly. Report unavailable delegation honestly; switching roles within the coordinator does not provide independent review. See the [subagent configuration](https://learn.chatgpt.com/docs/agent-configuration/subagents#custom-agents) and [skill discovery](https://learn.chatgpt.com/docs/build-skills#where-codex-loads-local-skills) documentation.

## Continue and Resume

For work spanning turns, the human may explicitly use the following in the same coordinating chat when the client supports it:

```text
/goal Use auto-loop to advance Idea.md within this chat's existing scope and budget.
Reach an evidence-supported stage judgment, complete necessary independent review,
and save progress and a recovery point in LOOP.md. Continue justified diagnosis and
exploration after a single hypothesis fails. Hand off truthfully when the budget is
exhausted or a real blocker occurs. If Idea is still an example, only check the input.
```

To resume, say "Use auto-loop to resume the previously authorized task." The coordinator rereads the formal rules and checks the original task, Idea, exploration record, actual processes, code version, and artifacts, preserving the accumulated budget. Determine whether work is still running before restarting to avoid duplicates. A new chat needs the original scope and intent to resume. See the [Codex long-running work documentation](https://learn.chatgpt.com/docs/long-running-work) for capabilities and limits.

## Execution Boundaries

Role separation and fresh contexts do not enforce operating-system isolation. The template depends on the actual Codex tools and local environment; it does not deploy an external scheduler, a separate read-only sandbox, or an unattended service. Enforced file and data boundaries require an external execution environment agents cannot modify. See the [permission controls](https://learn.chatgpt.com/docs/agent-configuration/subagents#approvals-and-sandbox-controls).

The template and static configuration checks do not establish scientific validity, automatic role discovery, prevention of duplicate concurrent starts, or long-run stability. End-to-end research execution on Windows has not been tested in this edition. Future conclusions require the actual project's evidence and independent review.

## Open-Source License and Introduction

This template uses the [MIT License](LICENSE). See the [Chinese introduction](https://github.com/Haichuan-Zhao/Auto-Loop) and [English introduction](https://github.com/Haichuan-Zhao/Auto-Loop/blob/main/README.en.md) for concise overviews and package downloads.
