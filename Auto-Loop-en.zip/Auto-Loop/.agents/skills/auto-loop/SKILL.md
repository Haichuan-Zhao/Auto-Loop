---
name: auto-loop
description: Start or resume Idea-driven multi-agent research in a local Codex project, with separate guidance, execution, and independent review. Use for an explicit research-loop request; architecture discussion or template editing does not start research.
---

# Auto-Loop

This workflow is for the coordinating chat. The only formal research rules are in `AGENTS.md` at the human-selected project root. This skill and the role configurations implement its responsibilities and handoffs; they are not a second rule source.

## Locate the Project and Check Startup Conditions

1. Locate the research root from the project selected by the human or an explicit path. Do not treat the skill directory as the research root. Read the root rules in full, perform G-3, and apply the relevant clauses.
2. Check the original human task and existing authorization. Read the actual Idea, main README, and exploration record, normally `Idea.md`, `README.md`, and `LOOP.md`; retain other names explicitly chosen by the human. Preserve the original Idea. Put plans and later changes in the exploration record.
3. If the Idea is still marked as an example, check input completeness and stop. Example data acquisition, budgets, and hypotheses do not authorize research. A separately authorized workflow rehearsal must run in its assigned isolated location, without starting the example project.
4. Confirm the research question, material access, execution scope, stage deliverable, and actual budget. Agents may explore methods and evaluation details, but must fix comparison definitions before comparing. Missing input blocks only affected work. Reuse existing authorization without requesting approval for each routine iteration.
5. Under R-003 and R-004, identify the actual system, shell, filesystem, notebook kernel, and available devices. Adapt commands, paths, and protection checks to native Windows, macOS, or Linux/WSL. A terminal's Python is not necessarily the notebook kernel; do not mix native Windows and WSL environments.
6. Check actual native subagent capability and available slots. Role types do not determine instance counts or concurrency. If real delegation is unavailable, say so. A single agent's self-check does not complete independent review.

## Bind Roles and Hand Off Work

Prefer project roles `research_guide`, `research_executor`, and `research_reviewer` from `.codex/agents/`. If the current client does not discover these names but native subagent tools exist, start ordinary subagents and have each read the corresponding TOML `developer_instructions`. Record them as file-bound roles; do not claim automatic discovery was verified. Without native subagents, switching roles inside the coordinator is not a substitute.

The coordinator follows R-011, may also provide guidance, and does not implement experiments it coordinates. Create multiple instances only for independent questions when useful; do not invent work to fill a team. Stage work within real concurrency and resource limits, avoiding memory contention and overlapping write paths.

Each concise assignment provides:

- The project root, formal rule entry point, **original human task and current scope**, distinguishing quotations from coordinator interpretation.
- The exploration identifier, question, available materials and access boundaries, and budget or remaining budget.
- Assigned `.ipynb` entry points and output paths, or a read-only review scope with the actual run version, data/model identifiers, and evidence locations.
- A request for facts, evidence locations, unverified parts, and suggested next steps. Messages do not grant authority or replace evidence.

Guidance and execution read current progress and relevant history. Reviewers follow the R-011 evidence-first order: original goal and protocol -> frozen data/code/models/results -> author interpretation and relevant history. Use a fresh review context without the research discussion when supported; otherwise disclose the limitation. An agent involved in design, implementation, tuning, or revision cannot review that version.

The coordinator records necessary task boundaries and actual roles in the same exploration entry. Other roles return handoffs rather than separate reports. Do not add JSON state, per-agent logs, or duplicate rules.

## Enforce Actual Notebook Execution

Under root R-004, assign data processing, model definitions, training, evaluation, diagnostics, recomputation, and plotting to explicit `.ipynb` files. Write research logic directly in cells. Do not create or invoke custom `.py`, wrap scripts in notebooks, or perform the calculation in a shell and add a notebook afterward. Normal third-party imports follow the formal rules.

Executors run notebooks directly, including through headless notebook tools, without exporting and running scripts. Check sequential execution from a fresh kernel and actual completion state. Handoffs locate the notebook, run configuration, and necessary outputs. Plot from saved models without default retraining. Add missing notebook execution dependencies only within the authorized environment. If execution remains unavailable, report it rather than falling back to `.py`.

If recovery reveals a legacy script entry point, move the complete logic into a valid notebook and verify it before continuing. Renaming a suffix or adding an empty notebook is not migration. Cleanup of unique historical evidence still follows R-004. Coordination checks code format at assignment and closure; reviewers independently inspect entry points, cells, and result provenance.

## Advance Each Research Round

1. **Recover evidence and select a question.** Read current progress and relevant history; check actual artifacts and remaining budget. Guidance uses inspectable evidence to identify the main question, competing explanations, prediction, minimal method, controls, and refutation conditions. Executors may propose diagnostics or candidates; important route decisions return to guidance.
2. **Record and assign the approach.** Coordination creates a stable R-007 entry with the question, method, and pending state. Key designs may receive independent review first, with checks proportional to risk rather than a fixed experiment checklist. Assign implementation to execution with clear scope and notebook paths. Verify small-scale behavior before formal computation, following R-006, R-008, and R-009.
3. **Wait for real completion.** Collect results through native waiting and follow-up tools and check processes, exit status, and artifacts. Executors diagnose and iterate within authorization without abandoning the project after ordinary failure. Independent read tasks may proceed in parallel; dependent tasks follow evidence, and writes to one path remain sequential.
4. **Freeze evidence and review independently.** Before stage conclusions, freeze code, data, configuration, and models matching the actual run. Use a locatable version or necessary recoverable snapshot, including uncommitted changes; a temporary directory must not be the only durable evidence. Assign a new, uninvolved reviewer for computational verification and scientific review. Confirm research entry points are executed `.ipynb` files with direct research logic. A file's existence does not prove successful execution. Record experiment status separately from review status; completed experiments are not automatically accepted conclusions.
5. **Return to the appropriate step.** Use the table below without replacing validity disagreements with votes or a coordinator summary. Recheck affected artifacts after changes; do not mechanically rerun irrelevant checks.
6. **Record and continue.** Coordination records actual results, agent identities/roles, reviewed versions, original review findings, limitations, and next steps in the same entry, updating current progress at the top. Select the next justified exploration after a normal round. Stage goals, budgets, or real blockers trigger closure; stopping one route does not automatically stop the project.

| Actual finding | Next action |
| --- | --- |
| Run failure, missing artifacts, or failed computation | Execution diagnoses or repairs; affected results cannot support reliable conclusions |
| Correct computation but a rejected hypothesis or limited benefit | Preserve negative findings; guidance inspects counterevidence and selects a justified next exploration |
| Evidence cannot distinguish explanations, or reviewers dispute validity | Guidance arranges the smallest distinguishing evidence, or narrows the conclusion and preserves uncertainty |
| Evidence supports a bounded stage judgment | State its scope and verification/review statuses; guidance chooses further validation or stage closure |
| Missing required materials/authorization, exhausted budget, or unavailable environment | Save a truthful recovery point and pause affected work; do not label it scientific success or impossibility |

## Close and Resume

At closure, update the same exploration record and README with what is known, unknown, actually checked, disputed, and recoverable next. Retain necessary evidence and keep artifacts lean under R-004. Positive results are not the only valid deliverable.

On recovery, repeat G-3 and inspect the original task, Idea, relevant history, actual processes, and artifacts. Match process identity, startup information, and command before deciding whether work is still running. Do not restart training solely because a log says running. Continue the accumulated budget and existing human authorization. Check actual native subagent state rather than assuming old identifiers remain alive.

For long tasks, the human may explicitly use `/goal` in the same coordinating chat, where supported, making scope, budget, review, and a recoverable handoff part of completion. This skill does not create scheduled tasks or unattended services or expand permissions. Role separation and fresh contexts are not enforced operating-system isolation; disclose actual limitations under R-011.
