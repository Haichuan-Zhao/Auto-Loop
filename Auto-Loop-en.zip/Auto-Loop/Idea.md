# Example Idea: Estimate Battery Health from a Short Charging Segment

**Input status: example, not started.** This file demonstrates how to describe a research idea to Codex. The project, hypotheses, evaluation choices, and budget below are examples. No real research data have been provided, and no literature verification or experiments have been completed. Loading this example permits only an input-completeness check; it does not authorize the example research.

This file contains research input, not formal rules. Follow root `AGENTS.md`; see `README.md` for startup. The human maintains the input. Agents record checks, plans, and subsequent changes in `LOOP.md` while preserving the original research intent.

## Replace This Example with Your Own Idea

- Keep useful headings and replace the example with actual content. Adapt the objects, methods, and evaluation for another field.
- At minimum, state the question and use case, material acquisition and access conditions, desired results, execution scope, and budget. Materials may be existing paths or permission to find suitable public data. If methods, mechanisms, specific papers, or evaluation details are unknown, write "for agents to explore"; you need not design the entire route in advance.
- Give actual data locations, permissions, and budgets, or explicitly state "not provided." Distinguish ideas, other people's reports, and your own measurements. Link observations to inspectable evidence.
- For real exploration, change the input status above to "ready for exploration" and explicitly start it in the coordinating chat. Do not run research while the file remains an example.

## 1. The Idea in One Sentence

Can a short charging record support a simple, interpretable battery state-of-health estimator that transfers to previously unseen batteries without complete aging labels for the target battery, while identifying the observation requirements and failure conditions?

I want agents to discover justified patterns, formulate testable hypotheses, and choose methods. A valid outcome may be that the idea fails or holds only under narrow conditions.

## 2. Research Question and Use Case

| Item | Example setting |
| --- | --- |
| Object | Rechargeable batteries with repeated charge/discharge records; chemistry, model, and conditions await data inspection |
| Use case | Observe a short segment of a charging event for a battery unseen during training and estimate its capacity-based health at that time |
| Inputs available at deployment | Time, voltage, and current within the segment; temperature only if actually available in the deployment scenario and recorded in the data |
| Target | Example definition: `SOH = 100 x current reference capacity / rated capacity`, in percent; first verify that capacity measurement definitions and the rated-capacity source support it |
| Label use | Full capacity measurements create labels and support evaluation; they are not inputs for that short-segment prediction |
| Generalization | Initially, unseen batteries within the same chemistry and declared operating range; cross-chemistry transfer is not a default goal |
| Main uncertainty | Whether a short segment contains enough information, and whether identity, conditions, or measurement differences obscure health information |

Main question: can a short segment reveal structure useful for health estimation without relying mainly on accidental correlations with battery identity or operating conditions?

Further questions: is this structure stable across observation lengths, numbers of training batteries, and permitted conditions, and when should the method report insufficient information?

## 3. Motivation and Current Knowledge

### Task Settings Already Chosen

- Reduce observation requirements at deployment while retaining checkable predictive performance and explicit applicability boundaries.
- Prioritize unseen-battery performance. Results on a battery seen during training answer a different question.

These are research goals, not experimentally established domain findings.

### My Own Observations

No measured observations have been provided. Do not claim that a voltage interval is especially useful, a model fails, or an improvement reaches a particular value.

For an actual project, an observation might say: "Under this data version, split, and code version, I observed this behavior, with evidence at ...; this alternative explanation remains unresolved."

### Initial Hypotheses, All Unverified

- H1: some charging segments may contain information that distinguishes health states; information may vary with segment position and length.
- H2: if major changes unrelated to health can be identified and controlled, a simple representation or model may suffice.
- H3: some difficult samples may lack identifiable information in the inputs, so a more complex model may not resolve the problem.

Competing explanations include temperature, battery identity, cycle number, batch, or sampling choices accounting for the apparent prediction quality.

Agents may reject, refine, or replace these hypotheses. Preserve revisions and counterevidence in `LOOP.md`.

## 4. Available Data, Code, and References

| Material | Location or source | Status and checks needed |
| --- | --- | --- |
| Raw data | Not provided; replace with an accessible path or public download page | Check provenance, license, version, fields, units, and battery/batch identifiers |
| Data documentation | Not provided | Check capacity-label measurement, time definitions, and rated-capacity sources |
| Existing code and models | Not provided | No baseline can currently be claimed as reproduced |
| References | Not provided | Public searches may be used; obtain and inspect the text before citing specific findings |
| Historical results | None | No real metrics, run records, or model artifacts |
| Independent test material | Not established | Define isolation before real execution; exploration must not inspect independent test content |

For an actual project, specify:

- Whether data are public, nonpublic, or sensitive, and which local processing and external calls are allowed.
- Whether the data have already informed model selection or tuning, and whether test results have been inspected.
- Possible duplicate samples, repeated records from one battery, batch dependence, or temporal dependence; explicitly ask agents to check unknowns.
- Whether files are complete, fields are missing, quality problems are known, or existing processing must be retained.

This example does not authorize transmission of nonpublic data. An existing directory does not prove that usable data exist, and an example path is not provenance.

Without an existing dataset, real input may say: "Agents may search for and select suitable public data whose license permits this research, verify sources and conditions, and obtain necessary material. Do not purchase data or create accounts independently." This allows an idea-driven start without requiring the human to preselect a dataset.

## 5. Intended Research Scope

- Keep the core goal: health estimation for unseen batteries using short-segment inputs, including information boundaries.
- Start with comparable operating conditions. Segment length, position, and sample size may be explicitly declared research variables.
- Select segments using information genuinely available at deployment. Do not use future capacity labels, complete future trajectories, or test performance to locate the "best segment."
- Do not prescribe a neural architecture in advance. Complexity follows the question, hypotheses, and evidence.
- Do not expand by default into remaining-life prediction, control strategies, a deployed product, or universal claims across all chemistries.
- If data do not support the target definition or key comparisons, identify the affected scope. Record scientific reasons for justified scope adjustments, and obtain explicit human direction for a material change of goal.

## 6. Evaluation Preferences

The following evaluation choices are examples and may be replaced. Before formal comparison, check that they fit the data and use case, and record the adopted protocol in `LOOP.md`.

- **Primary setting:** batteries unseen during training. Define groups and development splits from actual battery counts, batches, and dependencies. Use independent tests only after freezing the approach.
- **Primary metric:** calculate prediction MAE within each battery, then average equally across batteries. When SOH is expressed in percent, report absolute errors in percentage points, not as relative percentages.
- **Supporting information:** battery-level errors, spread and difficult samples, observation length, required training labels, and compute cost. Report necessary repetitions for random methods.
- **Baselines:** agents choose suitable simple and competitive baselines from literature and data, identifying implementations actually checked. Disclose inputs, data size, training, and tuning budgets.
- **Meaningful-improvement threshold:** not set. Before confirmatory comparison, propose and fix a justified threshold using application needs, measurement error, and baseline stability. Do not invent a required percentage improvement without a basis.
- **Mechanism checks:** choose controls that distinguish hypotheses, assess gains with comparable inputs, model size, and budget, and test whether confounding explains them.

Progress may mean discovering a bounded reproducible pattern, building an effective simple method, or producing reliable evidence about the idea's limitations. Requiring a positive improvement in advance undermines credible conclusions.

## 7. Decisions Left to Agents

- Verify what prior work has already answered and which questions remain worth investigating; do not repackage established findings as novelty.
- Check which questions real data can answer and identify useful phenomena and competing explanations.
- Choose representations, models, necessary derivations, baselines, and experiment order, prioritizing uncertainty that most affects judgment.
- Decide when to reproduce, add evidence, simplify, revisit assumptions, change route, or stop a route.

Possible entry points include input-information and confounding diagnostics, stability of simple representations, and observation requirements versus error. These are optional questions, not a required experiment sequence.

## 8. Execution Scope and Budget

**The values below are examples. No timer has started, and this section does not authorize the example research.**

| Item | Example entry |
| --- | --- |
| Stage objective | Explore one main hypothesis, perform necessary checks, and reach a stage conclusion; explicitly identify remaining uncertainty if unresolved |
| Total budget | At most 4 hours or 6 substantive research loops from startup through closure, whichever comes first; closure is included |
| Round scope | One main question and at most 3 predeclared scientific comparison conditions; combine necessary seeds/folds, choosing counts from verification needs and the total budget |
| Computation | Measure duration and memory at small scale before sizing formal runs; finish within budget while preserving evidence |
| Environment | The actual local Windows, macOS, or Linux/WSL environment; fill in system, shell, Python/notebook kernel, and available devices. No paid cloud or remote computation |
| Model usage | No additional numerical token budget specified; respect actual account limits and the scope above, saving progress if a limit is reached |
| Model and local tool permissions | Keep the real session's existing settings; this Idea does not expand tool or data permissions |

Closure conditions include sufficient evidence on the main question, refutation of a key hypothesis, an exhausted budget, continued work that adds no explanatory evidence with no new testable hypothesis, or missing required materials, definitions, or authorization.

When data are missing, continue literature checks and reasoning that do not depend on them. Do not invent data or substitute simulations for real measurements. If simulation is needed, explicitly state its purpose and label its nature.

## 9. Desired Deliverables

- `README.md` clearly states the question, actual data sources, stage conclusions, scope, and recomputation entry points.
- `LOOP.md` retains main hypotheses, controls, actual results, independent verification/review findings, failed routes, and next steps.
- Necessary executable code and model artifacts support key conclusions. Clearly label work that has not completed.
- Create clear JPG research figures only when informative; do not pre-create figures or result files to fill the template.
- Explain whether the idea merits continuation, needs narrower scope, remains unresolved, or should stop, with evidence.

This task does not request a complete paper, submission package, or public release of results.

## 10. Information Still Needed Before Startup

This example still needs confirmation of a real research goal, material acquisition or accessible paths and permissions, and an actual execution budget. Start only after those inputs and explicit startup authorization are present, then record real progress in `LOOP.md`. Agents may find a specific dataset within the authorized public-material scope; until then, advance only work that does not depend on it.

The method, specific baselines, and experiment sequence may remain open for multi-agent exploration and review under the formal rules and actual materials.
