# Exploration Record

## Current Progress

- Stage: cross-platform open-source template v1.9; no real research project has started.
- Current understanding: AGENTS.md is the only formal rule source. The skill and role configurations separate guidance, execution, and independent review. Idea.md remains an unstarted example; there are no real data, experiment results, or review conclusions.
- Environment: before use, check file protection, shell, Python/notebook kernel, dependencies, and devices for the actual system. The template does not assume the local environment.
- Unverified: scientific validity of a real project, role discovery in the current client, actual multi-agent operation, and end-to-end execution on the target platform. Static configuration or packaging checks are not scientific verification or platform runtime tests.
- Next: the human reads and protects the formal rules, replaces the Idea, and confirms scope, data permissions, and budget before startup. Begin actual research entries at E001.

## Exploration History

No research entries yet. Retain original questions, methods, actual results, negative findings, evidence locations, review statuses, and next steps. The entry format is in R-007 of AGENTS.md.
