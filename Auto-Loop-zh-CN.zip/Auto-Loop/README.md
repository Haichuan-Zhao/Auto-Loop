# Auto-Loop

由 Idea 文件驱动的多 agent 科研探索模板。主管负责协调，研究指导与探索执行由不同 agent 承担，未参与被审版本的审查者独立核验计算和科学解释。

唯一正式规则为 [AGENTS.md](AGENTS.md)，当前版本 v1.9（开源跨平台版）。本说明介绍使用方式；技能和角色配置落实流程，不增加或替代正式规则。当前 [Idea.md](Idea.md) 是未启动示例，尚无真实课题数据、实验或科研结论。

## 文件组成

```text
Auto-Loop/
├── AGENTS.md                         # 人类维护的正式规则，只读
├── Idea.md                           # 研究输入，含详细填写示例
├── README.md                         # 使用说明与课题说明入口
├── LOOP.md                           # 唯一探索记录
├── .agents/skills/auto-loop/
│   ├── SKILL.md                      # 主管运行流程
│   └── agents/openai.yaml            # 技能界面元数据
└── .codex/agents/
    ├── Guide.toml                    # research_guide
    ├── Executor.toml                 # research_executor
    └── Reviewer.toml                 # research_reviewer
```

迁移整套流程时保留隐藏目录 `.agents`、`.codex` 及根目录文件。资料、数据、方法、实验和图目录按实际需要创建；模板不预留空目录。开源包不含真实研究数据、实验结果或模板维护历史；[LOOP.md](LOOP.md) 从新课题的实际状态开始记录。

## 准备与启动

1. 在 Codex App 中打开真实课题根目录，使用本地环境。从此目录启动主管聊天。
2. 由人类按当前系统核对正式规则及保护，复制或克隆后重新检查。Windows 使用只读属性及实际 ACL 信息，macOS 检查写权限和人类设置的 `uchg`，Linux/WSL 检查实际文件系统的权限。基础只读设置不等于 agent 无权更改的强制隔离；agent 不修改规则或保护属性。具体命令见下方平台准备说明。
3. 将 `Idea.md` 的示例整体替换为真实研究问题、材料获取方式与访问条件、阶段目标及本次预算，状态改为“待探索”。方法、具体基线和探索路径可以留给 agent。
4. 在主管聊天中发送：

```text
使用 auto-loop 技能，读取当前项目的 Idea.md。
我授权本次使用 Codex 原生多 agent 协作，按根目录 AGENTS.md 开展研究。
你承担协调职责，实际分派研究指导、探索执行和独立审查任务，
各类角色数量按研究问题调整，保持指导与执行分离。
数据处理、训练、评估、复算与绘图均在 .ipynb 中编写并实际执行，
不创建或调用自编 .py，不用 notebook 包装脚本。
在 Idea 指定的范围与预算内持续推进，普通排错和方案内探索自主完成；
重要路线转向由指导方核对证据，阶段结论经过独立核验与科学评审。
将进展、证据版本、角色标识、审查状态与分歧集中记入 LOOP.md。
若 Idea 仍为示例，仅检查输入并报告待补信息，不启动课题。
```

保留人类原始 Idea，核查、计划和后续变化进入 `LOOP.md`。已有明确授权沿用，不为正常迭代逐次确认。复制成新课题时将 `LOOP.md` 初始化为该课题的实际状态，不继承模板维护历史作为科研证据。

## 平台准备

由人类在课题根目录执行适用命令：

- Windows（PowerShell）：`attrib +R ".\AGENTS.md"`，再用 `Get-Item -LiteralPath ".\AGENTS.md" | Select-Object Name, IsReadOnly` 和 `icacls ".\AGENTS.md"` 检查只读属性及 ACL。
- macOS：`chmod a-w AGENTS.md`、`chflags uchg AGENTS.md`，再用 `ls -lO AGENTS.md` 检查。
- Linux/WSL：`chmod a-w AGENTS.md`，再用 `ls -l AGENTS.md` 检查。WSL 的 Windows 挂载路径还需检查 Windows 侧权限。

普通只读属性或权限可能被同账户解除；更强的边界由人类在 agent 无权改变的执行环境中配置。ZIP/Git 不保证保留这些保护。文件属性与权限的含义见 [Microsoft attrib](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/attrib)、[icacls](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/icacls) 与 [WSL 文件权限](https://learn.microsoft.com/en-us/windows/wsl/file-permissions)。

在选定的 Python 环境中准备 notebook 内核和执行工具，例如 `ipykernel` 与 `nbclient`；科研依赖由实际课题决定。启动前确认 shell、Python/notebook 内核、依赖、路径与设备，Windows 原生与 WSL 环境不混用。Windows 可使用 PowerShell，参见 [Codex Windows 文档](https://learn.chatgpt.com/docs/windows/windows-sandbox)。

计算遵守 R-003：按实际支持选择 macOS 的 MPS、Windows/Linux/WSL 的 CUDA 等后端或 CPU，不预设 GPU 型号。Windows notebook 的 PyTorch DataLoader 先用 `num_workers=0` 验证，再决定是否增加 worker，参见 [PyTorch Windows FAQ](https://docs.pytorch.org/docs/stable/notes/windows.html)。科研实现仍直接写在 `.ipynb` 中。

## 运行与交接

流程入口是 [auto-loop 技能](.agents/skills/auto-loop/SKILL.md)：

```text
读取进展 → 指导方确定问题与证据要求 → 登记问题和方法
→ 执行方实现、小规模核验与实验 → 检查实际运行并固定证据
→ 独立核验计算与科学解释 → 修复、补证、调整路线或接受有限结论
→ 更新进展并继续
```

![Auto-Loop 科研闭环流程](Workflow.jpg)

科研代码格式按 R-004：实际代码入口为 `.ipynb`，模型与函数直接定义在代码单元中，结果由 notebook 实际执行产生。无界面执行仍运行 notebook，不导出或调用自编 `.py`；绘图加载已有模型复算，保留必要执行信息与关键结果。

三类角色可分别创建多个实例，按实际名额、资源和写入路径安排并发。指导方与执行方读取当前进展及相关历史；审查者先查固定原始证据，再对照作者解释，条件允许时使用新上下文。实验完成与审查通过分别记录；计算正确的负结果保留，指导方核对证据后选择下一项有依据的探索。

各 agent 直接读取共享项目中的有关文件。交接消息只需说明探索编号、问题、范围、证据版本与位置、可写路径、预算和未核验项；消息不代替证据或人类授权。主管集中维护 `LOOP.md` 和主说明，不另建 JSON 状态或逐 agent 日志。

角色名称未被客户端发现、但原生子 agent 可用时，让普通子 agent 读取相应 TOML，登记为“文件绑定角色”。技能未出现在入口时，可直接要求读取项目 `.agents/skills/auto-loop/SKILL.md`。没有实际委派能力时如实报告，不能在主管中切换角色冒充独立审查。配置格式和发现机制参考 [子 agent 配置](https://learn.chatgpt.com/docs/agent-configuration/subagents#custom-agents)与[技能加载](https://learn.chatgpt.com/docs/build-skills#where-codex-loads-local-skills)。

## 持续推进与恢复

需要跨回合推进且客户端支持时，由人类在同一主管聊天显式使用：

```text
/goal 使用 auto-loop，按本聊天已授权的范围与预算推进 Idea.md；
形成有证据的阶段判断，完成必要独立审查，并在 LOOP.md 保存进展与恢复位置。
单个假设失败后继续有依据的诊断与探索，预算耗尽或真实阻塞时如实交接。
若 Idea 仍为示例，仅完成输入检查。
```

恢复时发送“使用 auto-loop 恢复此前已授权的任务”。主管重读正式规则，核对原任务、Idea、探索记录、实际进程、代码版本及产物，延续累计预算；先确认是否仍在运行，再决定恢复，避免重复启动。新聊天需提供原任务范围和恢复意图。长期任务能力与限制见 [Codex 长期任务说明](https://learn.chatgpt.com/docs/long-running-work)。

## 执行边界

角色分工和新上下文不构成系统权限隔离。当前模板依赖 Codex 的实际工具能力与本地环境，未部署外部调度器、独立只读沙箱或无人值守服务。强制文件与数据访问边界需由 agent 无权修改的外部执行环境实现，参见[权限说明](https://learn.chatgpt.com/docs/agent-configuration/subagents#approvals-and-sandbox-controls)。

模板与静态配置检查不证明真实科研有效性、自动角色发现、并发重复启动防护或长期运行稳定性；本版尚未完成 Windows 端到端科研运行。后续结论只以相应课题的实际证据和独立审查为准。

## 开源许可与介绍

本模板采用 [MIT 许可](LICENSE)，标准许可正文保留英文。精简介绍及可下载文件见 [中文首页](https://github.com/Haichuan-Zhao/Auto-Loop)与[English](https://github.com/Haichuan-Zhao/Auto-Loop/blob/main/README.en.md)。
